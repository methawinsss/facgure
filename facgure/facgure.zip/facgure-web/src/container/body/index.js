import React from "react";

import Routers from "../../router";
const Container = () => {
  return <Routers />;
};

export default Container;
