import React, { useEffect } from "react";
import apiContact from "../../api/apiContact";
import apiCompany from "../../api/apiCompany";
import apiBlog from "../../api/apiBlog";
import apiOurSolution from "../../api/apiOurSolution";
const Footer = () => {
  useEffect(() => {
    console.log("ssss");
    /*func_loadContact();
    func_loadCompany();
    func_loadBlog();
    func_loadOutSolution(); */
  }, []);

  const func_loadContact = async () => {
    const res = await apiContact.getData();
    if (res.status) {
      const { data } = res.response;

      console.log(data);
    }
  };

  const func_loadCompany = async () => {
    const res = await apiCompany.getData();
    if (res.status) {
      const { data } = res.response;
      console.log(data);
    }
  };

  const func_loadBlog = async () => {
    const res = await apiBlog.getData();
    if (res.status) {
      const { data } = res.response;
      console.log(data);
    }
  };

  const func_loadOutSolution = async () => {
    const res = await apiOurSolution.getData();
    if (res.status) {
      const { data } = res.response;
      console.log(data);
    }
  };

  return (
    <div className="mb-10">
      <div className="footer-color minWidth">
        <div className="ml-auto mr-auto p-4 mt-1 minWidth flex-content-center text-left">
          <div className="pr-20">
            <div>Contact Us</div>
            <div className="mt-4">
              503/32 อาคาร เค.เอส.แอล. ทาวเวอร์, ชั้น 18,
              <br />
              ถนนศรีอยุธยา แขวงถนนพญาไท เขตราชเทวี
              <br />
              กรุงเทพมหานคร 10400
            </div>
            <div className="mt-4">contact@facgure.com</div>
            <div className="mt-4">+662-354-2555</div>
          </div>
          <div className="pr-20">
            <div>Company</div>
            <div className="mt-4">About us</div>
            <div className="mt-4">Contact us</div>
            <div className="mt-4">Careers</div>
            <div className="mt-4">Customer</div>
            <div className="mt-4">Support</div>
          </div>
          <div className="pr-20">
            <div>Blog</div>
            <div className="mt-4">Knowledge</div>
            <div className="mt-4">News & Event</div>
          </div>
          <div>
            <div>Our solution</div>
            <div className="mt-4">Business Application Development</div>
            <div className="mt-4">Business Intelligence Development</div>
            <div className="mt-4">UX/UI Design Studio</div>
            <div className="mt-4">Digital Transformation and Consultancy</div>
            <div className="mt-4">Azure Cloud Solution</div>
            <div className="mt-4">Server and Services Monitoring</div>
            <div className="mt-4">Microsoft Word and Office 365 Add-in</div>
          </div>
        </div>
      </div>
      <div className="ml-auto mr-auto mt-9 xl:w-9/12 minWidth">
        <div className="flex-content-center">
          <div>
            <img
              className="w-8"
              src="https://static.wixstatic.com/media/b5bf4b_e19ff48601204d579ce14bd904bb8763~mv2.gif"
            />
          </div>
          <div className="mt-2 ml-3">
            <img
              className="w-28"
              src="https://static.wixstatic.com/media/b5bf4b_ff8a56df349c48e4946f8d67f8b0cc72~mv2.png/v1/fill/w_112,h_28,al_c,q_85,usm_0.66_1.00_0.01,enc_auto/b5bf4b_ff8a56df349c48e4946f8d67f8b0cc72~mv2.png"
            />
          </div>
        </div>

        <div className="flex-content-center mt-3">
          <div>
            สิ่งสำคัญที่เราจะมอบให้กับลูกค้าไม่ใช่แค่เพียงการส่งมอบงาน
            แต่ต้องเป็นงานที่มีประสิทธิภาพ
          </div>
        </div>

        <div className="flex-content-center mt-3">
          <div>
            <img
              className="w-8"
              src="https://static.wixstatic.com/media/4057345bcf57474b96976284050c00df.png/v1/fill/w_31,h_31,al_c,q_85,usm_0.66_1.00_0.01,enc_auto/4057345bcf57474b96976284050c00df.png"
            />
          </div>
          <div className="ml-3">
            <img
              className="w-8"
              src="https://static.wixstatic.com/media/4057345bcf57474b96976284050c00df.png/v1/fill/w_31,h_31,al_c,q_85,usm_0.66_1.00_0.01,enc_auto/4057345bcf57474b96976284050c00df.png"
            />
          </div>
          <div className="ml-3">
            <img
              className="w-8"
              src="https://static.wixstatic.com/media/4057345bcf57474b96976284050c00df.png/v1/fill/w_31,h_31,al_c,q_85,usm_0.66_1.00_0.01,enc_auto/4057345bcf57474b96976284050c00df.png"
            />
          </div>
        </div>

        <div className="flex-content-center mt-3">
          <div>© 2021 | บริษัทแฟคเกอร์ จำกัด</div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
