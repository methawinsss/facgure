import React, { useEffect, useState } from "react";
import { Animated } from "react-animated-css";
const Dataprive = () => {
  const [offset, setOffset] = useState(0);

  useEffect(() => {
    const onScroll = () => setOffset(window.pageYOffset);

    window.removeEventListener("scroll", onScroll);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const [animateFeaturesFade, setAnimateFeaturesFade] = useState(false);
  const [animateFeaturesFade2, setAnimateFeaturesFade2] = useState(false);
  useEffect(() => {
    console.log(offset);
    if (offset > 220) {
      setAnimateFeaturesFade(true);
    }

    if (offset > 1700) {
      setAnimateFeaturesFade(true);
    }
  }, [offset]);

  return (
    <>
      <div className="ml-auto mr-auto mt-16" style={{ width: "1100px" }}>
        <div className="flex">
          <div className="text-5xl font-r" style={{ width: "25%" }}>
            <Animated
              animationIn="fadeInLeft"
              animationInDuration={1000}
              isVisible={true}
              animationInDelay={1000}
            >
              Dataprive
            </Animated>
          </div>
          <div style={{ width: "75%" }}>
            <div className="mt-7 w-full flex-content-end  pr-14">
              <div className="line-animetion-full"></div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-linear-gradient" />

      <div
        className="flex-content-center mt-20 ml-auto mr-auto minWidth xl:w-9/12"
        style={{ height: "550px" }}
      >
        <div className="flex-content-end" style={{ width: "40%" }}>
          <div className="mt-auto mb-auto">
            <div className="flex-content-end">
              <div className="text-left">
                <div className="text-5xl font-r text-blue">Dataprive</div>
                <div className="text-2xl mt-8">
                  คือแอปพลิเคชันสำหรับแจ้งนโยบาย
                  <br />
                  พรบ. คุ้มครองข้อมูลส่วนบุคคล PDPA
                  <br />
                  และขอความยินยอมในการจัดการข้อมูล
                  <br />
                  จากเจ้าของข้อมูล
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-span-2" style={{ width: "60%" }}>
          <Animated
            animationIn="fadeInRight"
            animationInDuration={1000}
            animationInDelay={2000}
            isVisible={true}
          >
            <img
              style={{ width: "800px", minWidth: "800px" }}
              src="https://static.wixstatic.com/media/b5bf4b_7cf6bcf2ad9146c1a44a3e03fb122876~mv2.png/v1/crop/x_0,y_65,w_801,h_563,q_90,enc_auto/b5bf4b_7cf6bcf2ad9146c1a44a3e03fb122876~mv2.png"
            ></img>
          </Animated>
        </div>
      </div>

      <div className="ml-auto mr-auto mt-24 xl:w-9/12 minWidth">
        <div className="text-2xl mt-8">
          ประเทศไทยได้ประกาศใช้พรบ. คุ้มครองข้อมูลส่วนบุคคลหรือ PDPA
          ซึ่งเป็นข้อบังคับที่ต้องปฎิบัติตาม
          <br />
          Dataprive
          ถูกพัฒนามาเพื่อให้ธุรกิจของคุณมีเครื่องมือที่ช่วยจัดการข้อมูลส่วนบุคคลให้เป็นไปตามที่
          <br />
          กฎหมายได้บัญญัติ
        </div>
      </div>

      <div className="ml-auto mr-auto mt-24 xl:w-9/12 minWidth">
        <div className="text-5xl mt-8" style={{ height: "90px" }}>
          <div className="text-fade">
            {animateFeaturesFade && "Features"}
            <div className={animateFeaturesFade ? "fadingEffect" : ""}></div>
          </div>
        </div>
        <div className="ml-auto mr-auto mt-2" style={{ width: "100px" }}>
          <div
            className={animateFeaturesFade ? "line-animetion-full" : ""}
            style={{ width: "0px" }}
          />
        </div>
      </div>

      <div className="ml-auto mr-auto mt-24 xl:w-9/12 minWidth">
        <div className="flex-content-center">
          <div className="flex-content-center">
            <div className="flex-content-center feature-boxs mt-auto mb-auto">
              <div className="mt-14">
                <div className="circle-inbox m-auto">
                  <div>1</div>
                </div>
                <div className="mt-10">
                  <div>
                    รองรับเอกสารขออนุญาต
                    <br />
                    แบบหลายฉบับ
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="flex-content-center ml-14 mr-14">
            <div className="flex-content-center feature-boxs mt-auto mb-auto">
              <div className="mt-14">
                <div className="circle-inbox m-auto">
                  <div>2</div>
                </div>
                <div className="mt-10">
                  <div>เชื่อมต่อได้หลายแพลตฟอร์ม</div>
                </div>
              </div>
            </div>
          </div>
          <div className="flex-content-center">
            <div className="flex-content-center feature-boxs mt-auto mb-auto">
              <div className="mt-14">
                <div className="circle-inbox m-auto">
                  <div>3</div>
                </div>
                <div className="mt-10">
                  <div>
                    การอ่านข้อมูลลูกค้าใหม่
                    <br />
                    สามารถทำได้เพียงแค่สแกน <br />
                    บัตรประชาชน
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="ml-auto mr-auto mt-10 xl:w-9/12 minWidth">
        <div className="flex-content-center">
          <div className="flex-content-center">
            <div className="flex-content-center feature-boxs mt-auto mb-auto">
              <div className="mt-14">
                <div className="circle-inbox m-auto">
                  <div>4</div>
                </div>
                <div className="mt-10">
                  <div>
                    เป็น paperless
                    <br />
                    ช่วยลดต้นทุนการใช้กระดาษ
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="flex-content-center ml-14">
            <div className="flex-content-center feature-boxs mt-auto mb-auto">
              <div className="mt-14">
                <div className="circle-inbox m-auto">
                  <div>5</div>
                </div>
                <div className="mt-10">
                  <div>
                    มีสำเนาเอกสารให้ผู้ขออนุญาต
                    <br />
                    และเจ้าของข้อมูล หลังจากกรอก
                    <br />
                    แบบฟอร์มขออนุญาต
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="ml-auto mr-auto mt-24 xl:w-9/12 minWidth">
        <div className="flex-content-center mt-8">
          <img src="https://static.wixstatic.com/media/b5bf4b_c96f68e416e348b3a5bca4cbc1a0aab7~mv2.png/v1/fill/w_89,h_89,al_c,lg_1,q_85,enc_auto/b5bf4b_c96f68e416e348b3a5bca4cbc1a0aab7~mv2.png" />
        </div>
      </div>

      <div className="ml-auto mr-auto mt-20 xl:w-9/12 minWidth">
        <div className="text-2xl mt-8">
          <div className="text-blue">Dataprive</div>
          <div>ช่วยคุ้มครองข้อมูลส่วนบุคคลของคุณอย่างปลอดภัย</div>
        </div>
      </div>

      <div className="ml-auto mr-auto mt-20 xl:w-9/12 minWidth">
        <div className="text-xl mt-8 goback">{"< กลับไปหน้าสิค้า"}</div>
      </div>

      <div className="ml-auto mr-auto mt-20 mb-20 flex-content-center minWidth xl:w-9/12">
        <img
          width={30}
          className="position-absolute-img minWidth"
          src="https://static.wixstatic.com/media/b5bf4b_df8965ea643e4b5fb1154025f54ae604~mv2.png/v1/crop/x_0,y_0,w_1218,h_265,q_85,enc_auto/b5bf4b_df8965ea643e4b5fb1154025f54ae604~mv2.png"
        />

        <div>
          <Animated
            animationIn="fadeInUp"
            animationInDuration={2000}
            animationInDelay={1000}
            isVisible={animateFeaturesFade2}
          >
            <div className="flex-content-center mt-4">
              <img src="https://static.wixstatic.com/media/b5bf4b_c96f68e416e348b3a5bca4cbc1a0aab7~mv2.png/v1/fill/w_89,h_89,al_c,lg_1,q_85,enc_auto/b5bf4b_c96f68e416e348b3a5bca4cbc1a0aab7~mv2.png" />
            </div>
            <div className="text-2xl mt-3 text-white">
              เยี่ยมชมเว็บไซต์ Dataprive.co
            </div>
            <div className="mt-3">
              <button className="btn-goto">ไปยังเว็บไซต์</button>
            </div>
          </Animated>
        </div>
      </div>
    </>
  );
};

export default Dataprive;
